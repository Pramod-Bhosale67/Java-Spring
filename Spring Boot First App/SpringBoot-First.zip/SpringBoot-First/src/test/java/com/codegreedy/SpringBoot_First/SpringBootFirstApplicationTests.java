package com.codegreedy.SpringBoot_First;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
